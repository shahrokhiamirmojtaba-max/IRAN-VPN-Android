package com.iranvpn.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private var selectedServer = "آلمان 🇩🇪"
    private lateinit var status: TextView
    private lateinit var connect: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 24, 39)
        window.navigationBarColor = Color.rgb(16, 24, 39)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 42, 28, 28)
            setBackgroundColor(Color.rgb(16, 24, 39))
        }

        val title = TextView(this).apply {
            text = "IRAN VPN"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "FAST  •  SECURE  •  SIMPLE"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 34)
        }
        root.addView(subtitle, matchWrap())

        status = TextView(this).apply {
            text = "قطع شده"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 8)
        }
        root.addView(status, matchWrap())

        val notice = TextView(this).apply {
            text = "برای اتصال واقعی، ابتدا باید فایل تنظیمات یک سرور WireGuard معتبر وارد شود."
            textSize = 14f
            setTextColor(Color.rgb(190, 200, 215))
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 24)
        }
        root.addView(notice, matchWrap())

        val serverLabel = TextView(this).apply {
            text = "انتخاب سرور"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.RIGHT
            setPadding(0, 10, 0, 10)
        }
        root.addView(serverLabel, matchWrap())

        val servers = listOf("آلمان 🇩🇪", "هلند 🇳🇱", "ترکیه 🇹🇷")
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, servers)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selectedServer = servers[position]
                }
            }
        }
        root.addView(spinner, matchWrap())

        connect = Button(this).apply {
            text = "اتصال"
            isEnabled = false
            alpha = 0.65f
            setOnClickListener {
                status.text = "برای اتصال، تنظیمات سرور لازم است"
            }
        }
        val buttonParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 28 }
        root.addView(connect, buttonParams)

        val footer = TextView(this).apply {
            text = "نسخه اولیه رابط کاربری • بدون سرور فعال"
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 30, 0, 0)
        }
        root.addView(footer, matchWrap())

        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )
}
